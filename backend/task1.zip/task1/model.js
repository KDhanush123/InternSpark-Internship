const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  sno: {
    type: Number,
    required: [true, 'Product serial number (sno) is required'],
    unique: true
  },
  name: {
    type: String,
    required: [true, 'Product name is required'],
    trim: true,
  },
  description: {
    type: String,
    required: [true, 'Product description is required'],
  },
  price: {
    type: Number,
    required: [true, 'Product price is required'],
    min: [0, 'Price must be a positive number'],
  },
  category: {
    type: String,
    required: [true, 'Product category is required'],
  },
  stock: {
    type: Number,
    required: true,
    default: 0,
    min: [0, 'Stock cannot be negative'],
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Product', productSchema);
